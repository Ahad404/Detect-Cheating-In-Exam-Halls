# cheating detection > 2023-03-16 2:57pm
https://universe.roboflow.com/suga-min-uqpff/cheating-detection-h9vke

Provided by a Roboflow user
License: CC BY 4.0

